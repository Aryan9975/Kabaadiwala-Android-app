package com.example.mykabadiwala_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class BuyerSellerActivity extends AppCompatActivity {
Button buyer;
Button seller;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer_seller2);
        buyer = findViewById(R.id.buyer);
        seller = findViewById(R.id.seller);
        buyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent( BuyerSellerActivity.this,SignIn.class);
                i.putExtra("type", "Buyer");
                startActivity(i);

            }
        });
        seller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent( BuyerSellerActivity.this,SignIn.class);
                i.putExtra("type", "Seller");
                startActivity(i);
            }
        });

    }
}