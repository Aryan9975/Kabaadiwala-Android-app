package com.example.mykabadiwala_2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.*;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.UploadProgressListener;

import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;

public class SignUp extends AppCompatActivity {
    private static final int REQUEST_CODE_STORAGE_PERMISSION =1;
    private static final int REQUEST_CODE_SELECT_IMG=2;
    EditText name,email,mobileno,password,address,aadharno,pincode;
    Button register,selectimg,selectaadharimg;
    ImageView img,aadharimg;
    public File img1;
    public File img2;
    public int r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        register = findViewById(R.id.registerr);
        name = findViewById(R.id.nameee);
        email = findViewById(R.id.emaill);
        password = findViewById(R.id.paswrd);
        mobileno = findViewById(R.id.mobilenoo);
        address = findViewById(R.id.addressss);
        aadharno = findViewById(R.id.aadharr);
        pincode = findViewById(R.id.pincode);
        selectimg=findViewById(R.id.selectimgg);
        selectaadharimg=findViewById(R.id.selectaadharimgg);
        img=findViewById(R.id.imgv);
        aadharimg = findViewById(R.id.aadharimgv);
        String type = getIntent().getStringExtra("type");
        selectimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               checkperm();
               r=0;
            }
        });
        selectaadharimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               checkperm();
               r=1;
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url="http://mykabaadiwala.in/api/signup";
                AndroidNetworking.upload(url)
                       // .addMultipartFile("image",file)
               // type, name, password , email, mobile, address, pincode, profile_image_url, adhaar_image_url, latitude,longitude, adhaar
                        .addMultipartParameter("type",type)
                        .addMultipartParameter("name",name.getText().toString())
                        .addMultipartParameter("password",password.getText().toString())
                        .addMultipartParameter("email",email.getText().toString())
                        .addMultipartParameter("mobile",mobileno.getText().toString())
                        .addMultipartParameter("address",address.getText().toString())
                        .addMultipartParameter("pincode",pincode.getText().toString())
                        .addMultipartFile("aadhar_img_url",img1)
                        .addMultipartFile("profile_img_url",img2)
                        .addMultipartParameter("latitude","100")
                        .addMultipartParameter("longitude","100")
                        .addMultipartParameter("aadharno",aadharno.getText().toString())



                        .setTag("uploadTest")
                        .setPriority(Priority.HIGH)
                        .build()
                        .setUploadProgressListener(new UploadProgressListener() {
                            @Override
                            public void onProgress(long bytesUploaded, long totalBytes) {
                                Log.d("responce_app",String.valueOf(bytesUploaded));
                            }
                        })
                        .getAsJSONObject(new JSONObjectRequestListener() {
                            @Override
                            public void onResponse(JSONObject response) {
                                Toast.makeText(SignUp.this,"Registered Successfully"+(response),Toast.LENGTH_LONG).show();
                            }
                            @Override
                            public void onError(ANError error) {
                                Toast.makeText(SignUp.this,error.toString(),Toast.LENGTH_LONG).show();


                            }
                        });
            }
        });


    }
    private void selectimg(){
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        if(intent.resolveActivity(getPackageManager())!=null){
            startActivityForResult(intent,REQUEST_CODE_SELECT_IMG);
        }

    }
    private void checkperm(){
        if(ContextCompat.checkSelfPermission(
                getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE
        )!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(
                    SignUp.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_CODE_STORAGE_PERMISSION
            );
        }else{
            selectimg();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull  String[] permissions, @NonNull  int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==REQUEST_CODE_STORAGE_PERMISSION && grantResults.length>0){
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                selectimg();
            }
            else{
                Toast.makeText(this,"Permission Denied",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable  Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
            if(requestCode==REQUEST_CODE_SELECT_IMG && resultCode==RESULT_OK){
                if(data!=null){
                    Uri selectedImageUri = data.getData();
                    if(selectedImageUri!=null){
                        try{
                            InputStream inputStream = getContentResolver().openInputStream(selectedImageUri);
                            Bitmap bitmap= BitmapFactory.decodeStream(inputStream);
                            if(r==0){
                            img.setImageBitmap(bitmap);
                         img1 = new File(getPathfromUri(selectedImageUri));
                            }
                            if(r==1){
                                aadharimg.setImageBitmap(bitmap);
                                 img2 = new File(getPathfromUri(selectedImageUri));
                            }
                        } catch (Exception exception) {
                           Toast.makeText(this,exception.getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
    }

    private String getPathfromUri(Uri contentUri){
        String filePath;
        Cursor cursor= (Cursor) getContentResolver()
                .query(contentUri,null,null,null,null);
        if(cursor==null){
            filePath=contentUri.getPath();}
        else{
            cursor.moveToFirst();
            int index= cursor.getColumnIndex("_data");
            filePath=cursor.getString(index);
            cursor.close();
        }
         return filePath;
    }
}